#include <iostream>
#include <cmath>
#include <stdio.h>
#define aa 10000000
#include <cstdlib>
#include <cstring>
#include "math.h"
#include <cstdio>
#include <cstring>
#include <algorithm>
#include <string>
#include <fstream>
using namespace std;
int c(int n)
{if ((n==1) or (n==2))
{return 1;}
else
{return c(n-2)+c(n-1);}
}
void b(int in)
{while (in!=1324)
{cout<<"error";}}
int main()
{
setlocale(0,"""");

long int a,aaa,aaaa=0,aaaaaa=1282;
cin>>a;

for (int i=0;i<aa*a;i++)
{for (int j=aa;j>23;j--)
{a++;
aaaa=aaaa+a*24*48;
if (a%10==0)//ahtung error(Диман, исправь до релиза, а то изи решение)
{i=j-3;
aaa=j;
}
}
}

while (abs(aaaa)!=(((68*23)/4)*((68*23)/4)+9)-332)
{aaaa--;
int aaaaa=0;
aaaaa+1000;
if (aaaaa%1000==0) cout<<"working"<<endl;
}
cout<<"молодец, нашел первый ключ"<<aaaa<<endl;//key1
int aaaaa=aaaa/aaaaaa;
b(aaaaa);
ifstream fin;
fin.open("key.txt");
int k,k1,mer;
fin>>k>>k;

int x=2,y=3;
unsigned long int key=146410000;
for (int i=0;i<aa;i++)
{k1=abs(aaaa)/1282;
key=sqrt(key);
key=pow(key,x);
cout<<"кручу верчу";
if (i==aa-2)
{key=sqrt(sqrt(key));}
}


char kek,flag[50]="SibSUTIS CTF 2016 NOVOSIBIRSK";
int b=strlen(flag);
for (int i=0;i<b;i++)
{
	if (flag[i]==char(78))
	{cout<<"уверен?"<<endl;
		kek=flag[i];
	}
	}

while (mer!=5)
{mer=c(4);}


cout<<"SCTF{"<<char(k1)<<char(k)<<char(key+10)<<kek<<mer<<'r'<<"}";










    return 0;
}

